from __future__ import print_function

import base64
import json
import boto3
import string
import random
from elasticsearch import Elasticsearch, RequestsHttpConnection

print('Loading function')

indexDoc = {
    "dataRecord" : {
        "properties" : {
          "record_id" : {
            "type" : "text"
          },
          "payer_name" : {
            "type" : "text"
          },
          "payer_id" : {
            "type" : "text"
          },
          "provider_id" : {
            "type" : "text"
          },
          "provider_name" : {
            "type" : "text"
          },
          "provider_service_number" : {
            "type" : "text"
          },
          "provider_address" : {
            "type" : "text"
          },
          "physician_id" : {
            "type" : "text"
          },
          "physician_name" : {
            "type" : "text"
          },
          "physician_mobile" : {
            "type" : "text"
          },
          "physician_email" : {
            "type" : "text"
          },
          "patient_id" : {
            "type" : "text"
          },
          "patient_name" : {
            "type" : "text"
          },
          "patient_ssn" : {
            "type" : "text"
          },
          "patient_address" : {
            "type" : "text"
          },
          "record_ts" : {
            "type" : "date",
            "format" : "date_optional_time"
          }
        }
      },
    "settings" : {
        "number_of_shards": 1,
        "number_of_replicas": 0
      }
    }

indexDoc2 = {
    "dataRecord" : {
        "properties" : {
          "record_id" : {
            "type" : "text"
          },
          "payer_name" : {
            "type" : "text"
          },
          "payer_id" : {
            "type" : "text"
          },
          "provider_id" : {
            "type" : "text"
          },
          "provider_name" : {
            "type" : "text"
          },
          "provider_service_number" : {
            "type" : "text"
          },
          "provider_address" : {
            "type" : "text"
          },
          "physician_id" : {
            "type" : "text"
          },
          "physician_name" : {
            "type" : "text"
          },
          "physician_mobile" : {
            "type" : "text"
          },
          "physician_email" : {
            "type" : "text"
          },
          "patient_id" : {
            "type" : "text"
          },
          "patient_name" : {
            "type" : "text"
          },
          "patient_ssn" : {
            "type" : "text"
          },
          "patient_address" : {
            "type" : "text"
          },
          "record_ts" : {
            "type" : "date",
            "format" : "date_optional_time"
          },
          "status" : {
            "type" : "text"
          }
        }
      },
    "settings" : {
        "number_of_shards": 1,
        "number_of_replicas": 0
      }
    }

def connectES(esEndPoint):
    print ('Connecting to the ES Endpoint {0}'.format(esEndPoint))
    try:
        esClient = Elasticsearch(
            hosts=[{'host': esEndPoint, 'port': 443}],
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection)
        return esClient
    except Exception as E:
        print("Unable to connect to {0}".format(esEndPoint))
        print(E)
        exit(3)

def createIndex(esClient):
    try:
        res = esClient.indices.exists('edi-270')
        if res is False:
            esClient.indices.create('edi-270', body=indexDoc)
        res2 = esClient.indices.exists('edi-271')
        if res is False:
            esClient.indices.create('edi-271', body=indexDoc2)
	    return 1
    except Exception as E:
            print("Unable to Create Index {0}".format("edi-270/edi-271"))
            print(E)
            exit(4)

def indexDocElement(esClient,table,response):
    try:
	 payerName = response['payer_name']
	 payerId = response['payer_id']
	 providerId = response['provider_id']
	 providerName = response['provider_name']
	 providerServiceNumber = response['provider_service_number']
	 providerAddress = response['provider_address']
	 physicianId = response['physician_id']
	 physicianName = response['physician_name']
	 physicianMobile = response['physician_mobile']
	 physicianEmail = response['physician_email']
	 patientId = response['patient_id']
	 patientName = response['patient_name']
	 patientSSN = response['patient_ssn']
	 patientAddress = response['patient_address']
	 recordId = response['record_id']
	 recordTs = response['record_ts']
	 status = ['Accepted','Accepted','Accepted','Accepted','Rejected']
	 retval = esClient.index(index='edi-270', doc_type='EDI-270-Request', body={
	     'record_id': recordId,
	     'record_ts': recordTs,
	     'payer_name': payerName,
	     'payer_id': payerId,
	     'provider_id': providerId,
	     'provider_name': providerName,
	     'provider_service_number': providerServiceNumber,
	     'provider_address': providerAddress,
	     'physician_id': physicianId,
	     'physician_name': physicianName,
	     'physician_mobile': physicianMobile,
	     'physician_email': physicianEmail,
	     'patient_id': patientId,
	     'patient_name': patientName,
	     'patient_ssn': patientSSN,
	     'patient_address': patientAddress
	 })
	 retval2 = esClient.index(index='edi-271', doc_type='EDI-271-Response', body={
	     'record_id': recordId,
	     'record_ts': recordTs,
	     'payer_name': payerName,
	     'payer_id': payerId,
	     'provider_id': providerId,
	     'provider_name': providerName,
	     'provider_service_number': providerServiceNumber,
	     'provider_address': providerAddress,
	     'physician_id': physicianId,
	     'physician_name': physicianName,
	     'physician_mobile': physicianMobile,
	     'physician_email': physicianEmail,
	     'patient_id': patientId,
	     'patient_name': patientName,
	     'patient_ssn': patientSSN,
	     'patient_address': patientAddress,
	     'status' : random.choice(status)
	 })
	 table.put_item(
	     Item={
	         'record_id': recordId,
	         'payer_name': payerName,
	         'provider_id': providerId,
	         'provider_name': providerName,
	         'provider_service_number': providerServiceNumber,
	         'provider_address': providerAddress,
	         'physician_id': physicianId,
	         'physician_name': physicianName,
	         'physician_mobile': physicianMobile,
	         'physician_email': physicianEmail,
	         'patient_id': patientId,
	         'patient_name': patientName,
	         'patient_ssn': patientSSN,
	         'patient_address': patientAddress,
	         'record_ts': recordTs
	    })
    except Exception as E:
	    print("Document not indexed")
	    print("Error: ",E)
	    exit(5)

def lambda_handler(event, context):
    esClient = connectES("oldelasticsearchep")
    createIndex(esClient)
    dynamodb = boto3.resource('dynamodb', region_name='oldawsregion')
    table = dynamodb.Table('olddynamodbstreamtable')
    for record in event['Records']:
        payload = base64.b64decode(record['kinesis']['data'])
        payload = payload.replace('\\"','"')
        payload = payload[1:-1]
        try:
         response = json.loads(payload)
         indexDocElement(esClient,table,response)
        except Exception as e:
            print(e)
            print('Processing failed')
            raise e