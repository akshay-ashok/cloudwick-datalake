from __future__ import print_function
import psycopg2
import boto3
import botocore
import json
import decimal
import re
import traceback
import urllib
from boto3.dynamodb.conditions import Key, Attr
from cStringIO import StringIO

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o%1 > 0:
                return float(o)
            else:
                return int(o)
            return super(DecimalEncoder, self).default(o)
            
def data_handler(event, context):
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.filter(Prefix='uploads/original'):            
        key = obj.key
        bucket_nm = obj.bucket_name
        table_name_attr = ""
        if not key.endswith('/'):
            try:
                attributes = []
                validator = []
                masking = []
                indx = []
                map_col = []
                body = obj.get()['Body'].read()
                schema = body.split('\n', 1)[0]
                data = body.split('\n')[1:][:-1]
                schema_list = schema.replace('\r','').split(',')
                split_key = key.split('/')
                file_name = split_key[-1]
                table_name_attr = file_name.split('_')[0].lower().strip()
         
                dynamodb = boto3.resource('dynamodb', region_name='oldawsregion')
                table = dynamodb.Table('olddynamodbmasktable')
                response = table.query(
                    KeyConditionExpression=Key('Table_Name').eq(table_name_attr)
                )

                if response['Items']:
                    for i in response['Items']:
                        attributes.append(i['Attribute_Name'])
                        validator.append(i['RegEx_Validator'])
                        masking.append(i['RegEx_Masking'])

                    if 'None' in attributes:
                        s3_resource = boto3.resource('s3')
                        s3_resource.Object(bucket_nm,'uploads/masked/%s_masked'%file_name).copy_from(CopySource='%s/uploads/original/%s'%(bucket_nm,file_name), ServerSideEncryption='AES256')
                        s3_resource.Object('%s'%bucket_nm,'uploads/original/%s'%file_name).delete()

                        print("started redshift")
                        filenm = 's3://%s/uploads/masked/%s_masked'%(bucket_nm,file_name)
                        conn_string = "dbname='oldredshiftdbname' port='5439' user='oldredshiftadmin' password='oldredshiftpassword' host='oldredshiftep'"
                        conn = psycopg2.connect(conn_string);
                        sql="""COPY %s FROM '%s' IAM_ROLE 'oldredshiftiamarn' CSV delimiter ',' IGNOREHEADER 1;"""%('%s'%table_name_attr, filenm)
                        cur = conn.cursor()
                        cur.execute(sql)
                        conn.commit()
                        cur.close()
                        print("redshift copy finished") 
                    else:   
                        for att in attributes:
                            indx.append(schema_list.index(att))
                        
                        map_table = dynamodb.Table('olddynamodbmaptable')
                        map_response = map_table.query(
                            KeyConditionExpression=Key('Table_Name').eq(table_name_attr)
                        )
                        
                        masked_data = schema
                        schema_map = schema.replace('\r','').split(',')

                        for i in map_response['Items']:
                            if i['Source_Attribute'] in schema_map:
                                masked_data = masked_data.replace(i['Source_Attribute'],i['Target_Attribute'])
                        
                        for line in data or []:
                            masked_line = ""
                            line_split = line.split(',')
                            for j, val in enumerate(indx):
                                if attributes[j] == "email":
                                    match = re.match(validator[j], line_split[val])
                                    if match == None:
                                        masked_line = line.replace("%s"%line_split[val],"default")
                                    else:
                                        result = re.sub(r'%s'%masking[j],r'*',line_split[val])
                                        masked_line = line.replace("%s"%line_split[val],"%s"%result)
                                elif attributes[j] == "ssn":
                                    match = re.match(validator[j],line_split[val])
                                    if match == None:
                                        masked_line = line.replace("%s"%line_split[val],"*****0000")
                                    else:
                                        masked_line = line.replace("%s"%line_split[val],"*****%s"%line_split[val][-4:])
                                else:
                                    print("line not asked")
                                line = masked_line
                            masked_data=masked_data+"\n"+masked_line
                        
                        # write processed data to masked folder
                        s3_client = boto3.client('s3')
                        fake_handle = StringIO(masked_data)
                        s3_client.put_object(Bucket=bucket_nm, Key='uploads/masked/%s_masked'%file_name, Body=fake_handle.read(), ServerSideEncryption='AES256')
                        print("masked data moved")

                        # load data to redshift tables
                        print("started redshift")
                        filenm = 's3://%s/uploads/masked/%s_masked'%(bucket_nm,file_name)
                        conn_string = "dbname='oldredshiftdbname' port='5439' user='oldredshiftadmin' password='oldredshiftpassword' host='oldredshiftep'"
                        conn = psycopg2.connect(conn_string);
                        sql="""COPY %s FROM '%s' IAM_ROLE 'oldredshiftiamarn' CSV delimiter ',' IGNOREHEADER 1;"""%('%s'%table_name_attr, filenm)
                        cur = conn.cursor()
                        cur.execute(sql)
                        conn.commit()
                        cur.close()
                        print("redshift copy finished") 

                        # move processed original files to unmasked folder
                        s3_resource = boto3.resource('s3')
                        s3_resource.Object(bucket_nm,'uploads/unmasked/%s_unmasked'%file_name).copy_from(CopySource='%s/uploads/original/%s'%(bucket_nm,file_name), ServerSideEncryption='AES256')
                        s3_resource.Object('%s'%bucket_nm,'uploads/original/%s'%file_name).delete()
                        print("backed up original files in masked folder")
                else:
                    print("file is invalid")
                    s3_resource = boto3.resource('s3')
                    s3_resource.Object(bucket_nm,'uploads/unprocessed/%s'%file_name).copy_from(CopySource='%s/uploads/original/%s'%(bucket_nm,file_name), ServerSideEncryption='AES256')
                    s3_resource.Object('%s'%bucket_nm,'uploads/original/%s'%file_name).delete()
                    print("moved invalid files")

            except Exception as e:
                print(traceback.format_exc())

