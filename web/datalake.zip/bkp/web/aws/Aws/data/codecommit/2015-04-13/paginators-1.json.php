<?php
// This file was auto-generated from sdk-root/src/data/codecommit/2015-04-13/paginators-1.json
return [ 'pagination' => [ 'GetDifferences' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', ], 'ListBranches' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'result_key' => 'branches', ], 'ListRepositories' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'result_key' => 'repositories', ], ],];
