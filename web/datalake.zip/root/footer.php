
        <?php
          require_once("../root/scripts.php");
        ?>
       </div>
      </div> <!-- end of container-fluid, spike -->
      <div class="container-fluid">
        <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer">
         <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1">
              Data Lake by <a href="http://cloudwick.com/" target="_blank" title="Cloudwick Technologies Inc.," class="text-center">Cloudwick Technologies Inc.<sup>&reg;</sup> </a>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <div class="visible-xs-block visible-sm-block"><br/><br/></div>
          </div>
         </div>
        </div>
        </div>
      </div>
</body>
</html>